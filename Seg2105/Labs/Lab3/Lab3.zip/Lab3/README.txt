Abdul Based Abdul Rahim - 300379200

	An Android development environment aiming to create a calculator
	Not quite finished, final touches need to be made
	
	for the most part complete and may be done by Saturday 28th September
	I could not finish it by midnight due to having to do the lab at 8 at night and needing to bus for an hour to 	get home 