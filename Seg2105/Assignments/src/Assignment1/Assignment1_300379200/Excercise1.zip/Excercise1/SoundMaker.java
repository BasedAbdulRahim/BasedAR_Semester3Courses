/*
an interface which holds the method make sound 
*/


public interface SoundMaker {
	
	void makeSound(); // makes a sound 
}
