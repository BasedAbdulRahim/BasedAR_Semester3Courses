Zuhair Zubair - 300378419
Abdul Based Abdul Rahim - 300379200
This is the submission where we weren't able to find the cause of the error, but said the code is correct.
2 Methods:
randomTrees - creates a bunch of trees where there is a set number of nods and trees, but the keys in the trees will be random. There will be both AVL and regular BST's and the random keys will go in both of them.

height - This should be able to find the height of any BST. I used a helper method to ensure that recursively, the height could be found. However, this was the method that ran into issues with the program not being able to see the height method.

